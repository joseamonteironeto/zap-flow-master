export default {
  "bootstrapScriptContent": "import(\"/_next/static/chunks/index-Boz-6mX7.js\")",
  "clientReferenceDeps": {
    "1b7d4de79c7e": {
      "js": [
        "/_next/static/chunks/index-Boz-6mX7.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/framework-D_rUT4EX.js"
      ],
      "css": []
    },
    "a5b3a26d3f69": {
      "js": [
        "/_next/static/chunks/index-Boz-6mX7.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/framework-D_rUT4EX.js"
      ],
      "css": []
    },
    "bb6bf7a7c7ac": {
      "js": [
        "/_next/static/chunks/index-Boz-6mX7.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/framework-D_rUT4EX.js"
      ],
      "css": []
    },
    "77c4985adffd": {
      "js": [
        "/_next/static/chunks/index-Boz-6mX7.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/framework-D_rUT4EX.js"
      ],
      "css": []
    },
    "c4538b25bbe6": {
      "js": [
        "/_next/static/chunks/layout-segment-context-4GbulHT-.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/index-Boz-6mX7.js",
        "/_next/static/chunks/framework-D_rUT4EX.js"
      ],
      "css": []
    },
    "2aad145d078b": {
      "js": [
        "/_next/static/chunks/index-Boz-6mX7.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/framework-D_rUT4EX.js"
      ],
      "css": []
    },
    "fe1de1a69edd": {
      "js": [
        "/_next/static/chunks/streamed-icons-DNogeH_Z.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/framework-D_rUT4EX.js",
        "/_next/static/chunks/index-Boz-6mX7.js"
      ],
      "css": []
    },
    "62277abed507": {
      "js": [
        "/_next/static/chunks/dashboard-wQDMst3P.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/index-Boz-6mX7.js",
        "/_next/static/chunks/framework-D_rUT4EX.js"
      ],
      "css": []
    }
  },
  "serverResources": {
    "app/layout.tsx": {
      "js": [],
      "css": [
        "/_next/static/css/index.ZRl7Hc1q.css"
      ]
    }
  }
}
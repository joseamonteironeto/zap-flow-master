import{n as e}from"./server-sSeWXiFG.js";import{env as t}from"cloudflare:workers";async function n(n){if(!t.DB)return e.json({logs:[]});let r=Number(new URL(n.url).searchParams.get(`limit`)||100),i=Math.max(10,Math.min(250,Number.isFinite(r)?r:100));try{let n=await t.DB.prepare(`
      SELECT id, level, stage, message, details_json AS detailsJson, group_jid AS groupJid,
        product_id AS productId, created_at AS createdAt
      FROM automation_logs ORDER BY created_at DESC LIMIT ?
    `).bind(i).all();return e.json({logs:n.results||[]})}catch(t){return console.error(`logs.list`,t),e.json({error:`Os logs ainda não estão disponíveis.`},{status:500})}}export{n as GET};
import{n as e,t}from"./link-resolver-BSrjYvp0.js";import{t as n}from"./mercadolivre-affiliate-DFdi8_6P.js";import{n as r,r as i}from"./integration-secret-CmyaqTM9.js";import{n as a,t as o}from"./mercadolivre-product-CSS9QgHW.js";import{env as s}from"cloudflare:workers";function c(e,t=300){return typeof e==`string`?e.trim().slice(0,t):``}async function l(e,t,n){let r=t?`${e}:${t}`:`url:${n}`,i=await crypto.subtle.digest(`SHA-256`,new TextEncoder().encode(r));return[...new Uint8Array(i)].map(e=>e.toString(16).padStart(2,`0`)).join(``)}async function u(){return s.DB?s.DB.prepare(`
    SELECT amazon_tracking_id AS amazonTrackingId,
      mercado_livre_label AS mercadoLivreLabel,
      amazon_enabled AS amazonEnabled,
      mercado_livre_enabled AS mercadoLivreEnabled
    FROM affiliate_settings WHERE id = 1
  `).first():null}async function d(e){if(!s.DB)throw Error(`Banco de dados indisponível.`);let t=new Date().toISOString(),n=await l(e.store,e.productCode,e.sourceUrl),r=crypto.randomUUID();return await s.DB.prepare(`
    INSERT INTO product_events
      (id, fingerprint, store, product_code, title, image_url, product_data_json, data_source, source_url, resolved_url, affiliate_url, status,
       source_group, destination_group, message_excerpt, redirect_count, occurrences, error_message, found_at, last_seen_at, sent_at, updated_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?, ?, NULL, ?)
    ON CONFLICT(fingerprint) DO UPDATE SET
      store = excluded.store,
      product_code = COALESCE(excluded.product_code, product_events.product_code),
      title = COALESCE(excluded.title, product_events.title),
      image_url = COALESCE(excluded.image_url, product_events.image_url),
      product_data_json = COALESCE(excluded.product_data_json, product_events.product_data_json),
      data_source = COALESCE(excluded.data_source, product_events.data_source),
      source_url = excluded.source_url,
      resolved_url = excluded.resolved_url,
      affiliate_url = COALESCE(excluded.affiliate_url, product_events.affiliate_url),
      status = CASE WHEN product_events.status = 'sent' AND excluded.status = 'converted' THEN 'converted' ELSE excluded.status END,
      source_group = COALESCE(excluded.source_group, product_events.source_group),
      destination_group = COALESCE(excluded.destination_group, product_events.destination_group),
      message_excerpt = excluded.message_excerpt,
      redirect_count = excluded.redirect_count,
      occurrences = product_events.occurrences + 1,
      error_message = excluded.error_message,
      last_seen_at = excluded.last_seen_at,
      updated_at = excluded.updated_at
  `).bind(r,n,e.store,e.productCode,e.title,e.imageUrl,e.productDataJson,e.dataSource,e.sourceUrl,e.resolvedUrl,e.affiliateUrl,e.status,e.sourceGroup||null,e.destinationGroup||null,e.messageExcerpt||null,e.redirectCount,e.errorMessage,t,t,t).run(),s.DB.prepare(`
    SELECT id, store, product_code AS productCode, title, image_url AS imageUrl,
      product_data_json AS productDataJson, data_source AS dataSource, source_url AS sourceUrl,
      resolved_url AS resolvedUrl, affiliate_url AS affiliateUrl, status, source_group AS sourceGroup,
      destination_group AS destinationGroup, message_excerpt AS messageExcerpt, redirect_count AS redirectCount,
      occurrences, error_message AS errorMessage, found_at AS foundAt, last_seen_at AS lastSeenAt,
      sent_at AS sentAt, updated_at AS updatedAt
    FROM product_events WHERE fingerprint = ?
  `).bind(n).first()}async function f(l){if(!s.DB)throw Error(`Banco de dados indisponível.`);let f=c(l.message,8e3),p=t(f);if(!p.length)return[];let m=await u(),h=s,g=l.cookies?.trim()?null:await r(`mercadolivre_session_cookies`),_=l.cookies?.trim()||g||h.MERCADOLIVRE_SESSION_COOKIES,v=[];for(let t of p){let r=await e(t),s=r.store===`mercadolivre`&&r.productCode?await o(r.productCode,r.resolvedUrl,_):null,u=r.store===`amazon`&&r.productCode?await a(r.productCode,r.resolvedUrl):null,p=s||u,h=null,g=r.store===`unknown`?`unsupported`:`found`,y=r.errorMessage;if(r.store===`amazon`&&m?.amazonEnabled&&m.amazonTrackingId){if(r.productCode)h=`https://www.amazon.com.br/dp/${r.productCode}?tag=${encodeURIComponent(m.amazonTrackingId)}`;else try{let e=new URL(r.resolvedUrl);e.searchParams.set(`tag`,m.amazonTrackingId),h=e.toString()}catch{h=null}g=`converted`,y=null}else if(r.store===`mercadolivre`&&r.productCode&&m?.mercadoLivreEnabled&&m.mercadoLivreLabel)if(!_)g=`waiting_credentials`,y=`Informe os cookies da sessão do Mercado Livre para gerar o link.`;else{let e=await n([r.resolvedUrl],m.mercadoLivreLabel,_);e.refreshedCookies&&(_=e.refreshedCookies,await i(`mercadolivre_session_cookies`,e.refreshedCookies)),e.ok&&e.results[0]?(h=e.results[0].short_url||e.results[0].long_url||null,g=h?`converted`:`error`,y=h?null:`O Mercado Livre não retornou o link gerado.`):(g=`waiting_credentials`,y=e.message)}let b=await d({...r,title:p?.title||r.title,imageUrl:p?.imageUrl||c(l.originalImageUrl,4e3)||r.imageUrl,productDataJson:p?.details?JSON.stringify(p.details).slice(0,6e4):null,dataSource:p?.source||null,affiliateUrl:h,status:g,sourceGroup:c(l.sourceGroup,160),destinationGroup:c(l.destinationGroup,160),messageExcerpt:f.slice(0,4e3),errorMessage:y});b&&v.push({...b,imageSource:p?.imageUrl?r.store===`amazon`?`amazon_catalog`:`mercadolivre_catalog`:c(l.originalImageUrl,4e3)?`original`:r.imageUrl?`resolved`:null})}return v}async function p(e,t){if(!s.DB||!e.length)return;let n=new Date().toISOString(),r=e.map(e=>s.DB.prepare(`
    UPDATE product_events SET status = 'sent', destination_group = ?, sent_at = ?, updated_at = ? WHERE id = ?
  `).bind(t||null,n,n,e));await s.DB.batch(r)}export{p as n,f as r,c as t};
import{env as e}from"cloudflare:workers";function t(e){if(!e)return null;try{return JSON.stringify(e,(e,t)=>typeof t==`string`&&t.length>500?`${t.slice(0,500)}…`:t).slice(0,4e3)}catch{return null}}async function n(n){if(e.DB)try{await e.DB.prepare(`
      INSERT INTO automation_logs (id, level, stage, message, details_json, group_jid, product_id, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `).bind(crypto.randomUUID(),n.level||`info`,n.stage.slice(0,60),n.message.slice(0,500),t(n.details),n.groupJid||null,n.productId||null,new Date().toISOString()).run()}catch{}}export{n as t};
import{n as e}from"./server-sSeWXiFG.js";import{env as t}from"cloudflare:workers";var n={amazonTrackingId:``,mercadoLivreLabel:``,redirectDomain:``,amazonEnabled:!0,mercadoLivreEnabled:!1};async function r(){if(!t.DB)return e.json({settings:n});let r=await t.DB.prepare(`
    SELECT amazon_tracking_id AS amazonTrackingId,
      mercado_livre_label AS mercadoLivreLabel,
      redirect_domain AS redirectDomain,
      amazon_enabled AS amazonEnabled,
      mercado_livre_enabled AS mercadoLivreEnabled
    FROM affiliate_settings WHERE id = 1
  `).first();return e.json({settings:r??n})}async function i(n){if(!t.DB)return e.json({error:`Banco de dados indisponível.`},{status:503});let r=await n.json();return await t.DB.prepare(`
    INSERT INTO affiliate_settings
      (id, amazon_tracking_id, mercado_livre_label, redirect_domain, amazon_enabled, mercado_livre_enabled, updated_at)
    VALUES (1, ?, ?, ?, ?, ?, ?)
    ON CONFLICT(id) DO UPDATE SET
      amazon_tracking_id = excluded.amazon_tracking_id,
      mercado_livre_label = excluded.mercado_livre_label,
      redirect_domain = excluded.redirect_domain,
      amazon_enabled = excluded.amazon_enabled,
      mercado_livre_enabled = excluded.mercado_livre_enabled,
      updated_at = excluded.updated_at
  `).bind(r.amazonTrackingId?.trim()??``,r.mercadoLivreLabel?.trim()??``,r.redirectDomain?.trim()??``,+!!r.amazonEnabled,+!!r.mercadoLivreEnabled,new Date().toISOString()).run(),e.json({ok:!0})}export{r as GET,i as PUT};
import{n as e}from"./server-sSeWXiFG.js";import{env as t}from"cloudflare:workers";async function n(){if(!t.DB)return e.json({configs:[]});let n=await t.DB.prepare(`SELECT jid, name, role, category, destination_jid AS destinationJid, enabled FROM group_configs ORDER BY name`).all();return e.json({configs:n.results??[]})}async function r(n){if(!t.DB)return e.json({error:`Banco de dados indisponível.`},{status:503});let r=await n.json(),i=Array.isArray(r.configs)?r.configs:[],a=new Date().toISOString(),o=i.map(e=>t.DB.prepare(`
    INSERT INTO group_configs (jid, name, role, category, destination_jid, enabled, updated_at)
    VALUES (?, ?, ?, ?, ?, ?, ?)
    ON CONFLICT(jid) DO UPDATE SET
      name = excluded.name,
      role = excluded.role,
      category = excluded.category,
      destination_jid = excluded.destination_jid,
      enabled = excluded.enabled,
      updated_at = excluded.updated_at
  `).bind(e.jid,e.name,e.role,e.category||`geral`,e.destinationJid||null,+!!e.enabled,a));return o.length&&await t.DB.batch(o),e.json({ok:!0,saved:o.length})}export{n as GET,r as PUT};